Function Parse-Steps{
    Param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [Array]
        $Data,

        $TaskName
    )
}
