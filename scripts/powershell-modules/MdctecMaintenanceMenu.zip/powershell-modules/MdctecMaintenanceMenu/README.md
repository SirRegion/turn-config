# MdctecMaintenanceMenu Powershell Module

This is a Windows PowerShell script module providing a console-based menu to execute several maintenance tasks related to complianceBase setup and infrastructure.


## Documentation
See the documentation in [this Confluence Page](http://192.168.8.112:8090/pages/viewpage.action?pageId=49709265)

## Downloads
Download the latest version [here](http://gitlab.mdctec.com/mdctec-developers/internal/infrastructure/-/jobs/artifacts/master/raw/scripts/powershell/MdctecMaintenanceMenu/MdctecMaintenanceMenu.zip?job=zip_MdctecMaintenanceMenu_module)
